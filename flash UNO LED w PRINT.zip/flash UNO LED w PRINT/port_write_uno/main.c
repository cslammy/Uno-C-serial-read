#include <avr/io.h>
#include <stdio.h>
#include "stdio_setup.h"

void Delay(void);

int main(void)
{
    UartInit();	
	
	printf("starting program \r\n");
	DDRB = 0x20;			// set bit 5 of DDR register which makes PB5 an output
    
	while(1)
	{
	    printf("LED ON \n\r");	
		PORTB = 0x20;		// switch LED on
		Delay();
		printf("LED OFF \n\r");
		PORTB = 0x00;		// switch LED off
		Delay();
	}
}

void Delay(void)
{
	volatile unsigned long count = 30000;

	while (count--);
}